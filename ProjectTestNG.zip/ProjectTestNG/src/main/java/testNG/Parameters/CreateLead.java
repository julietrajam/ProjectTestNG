package testNG.Parameters;


import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class CreateLead extends BaseClass {

	
	@Test(dataProvider = "fetchData")
	public void runCreateLead(String company,String fname,String lname,String id) {
		
		driver.findElement(By.linkText("Create Lead")).click();
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys(company);
		driver.findElement(By.id("createLeadForm_firstName")).sendKeys(fname);
		driver.findElement(By.id("createLeadForm_lastName")).sendKeys(lname);
		driver.findElement(By.id("createLeadForm_primaryPhoneNumber")).sendKeys(id);
		driver.findElement(By.name("submitButton")).click();
	
}
	
	@DataProvider(name="fetchData")
	public String[][] sendData()
	{
		String[][] data=new String[2][4];
		
		data[0][0]="Wipro";
		data[0][1]="Jose";
		data[0][2]="J";
		data[0][3]="301";
		
		data[0][0]="TCS";
		data[0][1]="Juls";
		data[0][2]="J";
		data[0][3]="302";
		
		return data;
		
	}
}






